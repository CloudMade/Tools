#!/usr/bin/env python
"""
 Copyright 2009 CloudMade.

 Licensed under the GNU Lesser General Public License, Version 3.0;
 You may not use this file except in compliance with the License.
 You may obtain a copy of the License at

      http://www.gnu.org/licenses/lgpl-3.0.txt

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
"""

"""CloudMade's geocoding API"""

import geometry
import urllib
import simplejson
from connection import Connection

from exception import ObjectNotFound

class Geocoding(object):
    """Class that is responsible for geocoding services of Cloudmade

    @ivar sub_domain: Subdomain of CloudMade's geocoding service
    @type sub_domain: C{str}
    @ivar connection: Connection object to be used by CloudMade's
    geocoding service
    @type connection: L{cloudmade.connection.Connection}
    
    """
    
    def __init__(self, connection):
        self.sub_domain = "geocoding"
        self.connection = connection
                 
    def find(self, query, results=10,
             skip=0, bbox=None, bbox_only=True, return_geometry=True, return_location=False):
        """
        Find objects that match given query
        Query should be in format [POI],[House Number],[Street],[City],[County],[Country]
        like "Potsdamer Platz, Berlin, Germany". 
        Also supported near in queries, e.g. "hotel near Potsdamer Platz, Berlin, Germany"

        @param query: Query by which objects should be searched.
        @type query: C{str}
        @param results: How many results should be returned.
        @type results: C{int}
        @param skip: Number of results to skip from beginning.
        @type skip: C{int}
        @param bbox: Bounding box in which objects should be searched.
        @type bbox: L{cloudmade.geometry.BBox}
        @param bbox_only: If set to False, results will be searched in the
        whole world if there are no results for a given bbox.
        @type bbox_only: C{bool}
        @param return_geometry: If specified, adds geometry in returned
        results. Defaults to True.
        @type return_geometry: C{bool}
        @param return_location: If specified, adds location information in returned
        results. Defaults to False.
        @type return_location: C{bool}
        @return: L{cloudmade.geocoging.GeoResults} objects.
        @rtype: L{cloudmade.geocoging.GeoResults}

        """
        params = {'return_geometry': return_geometry, 'return_location': return_location,
                  'bbox_only': bbox_only, 'results': results, 'skip': skip}
        if bbox:
            params['bbox'] = bbox.to_string()
        uri = "/geocoding/find/%s.js?%s" % (urllib.quote(query),
                                            urllib.urlencode(params))
        return self._call_service(uri)

    def find_closest(self, object_type, point, return_geometry=True, return_location=False):
        """Find closest object to a given point

        @note: For a list of available object types, see:
        http://www.cloudmade.com/developers/docs/geocoding-http-api/object_types

        @param object_type: Type of object, that should be searched.
        @type object_type: C{str}
        @param point: Closes object to this point will be searched.
        @type point: L{cloudmade.geometry.Point}
        @param return_geometry: If specified, adds geometry in returned
        result. Defaults to True.
        @type return_geometry: C{bool}
        @param return_location: If specified, adds location information in returned
        results. Defaults to False.
        @type return_location: C{bool}
        @return: Object that was found.
        @rtype: L{cloudmade.geocoging.GeoResult}
        @raise cloudmade.exception.ObjectNotFound: Raised when no object could
        be found in radius of 50 km from point.
    
        """
        params = {'return_geometry': return_geometry, 'return_location': return_location}
        uri = '/geocoding/closest/%s/%s.js?%s' % (urllib.quote(object_type), point.to_string(),
                       urllib.urlencode(params))
        try:
            return self._call_service(uri).results[0]
        except IndexError:
            message = ' '.join(("Object of type", object_type,
                                "was not found in 50 km radius from point",
                                str(point)))
            raise ObjectNotFound(message)
    
    def _call_service(self, uri):
        """Make the call to CloudMade's service using underlying connection

        @note: This is an internal method and shouldn't be used directly

        @param uri: Request string
        @type uri: C{str}
        @return: List of L{cloudmade.geocoging.GeoResult} objects that
        were produced after processing request.
        @rtype: C{list}
        
        """
        raw = self.connection.call_service(uri, self.sub_domain)
        parsed = simplejson.loads(raw)
        return GeoResults(parsed)


class Location(object):
    """Location of the object in geographical terms

    @ivar road: Road name on which object is situated
    @type road: C{str}
    @ivar city: City name, where the object is situated
    @type city: C{str}
    @ivar county: County name, where the object is situated
    @type county: C{str}
    @ivar country: Country in which the object is situated
    @type country: C{str}
    @ivar postcode: Postcode name, which corresponds to location of the
    object
    @type postcode: C{str}

    """
    
    def __init__(self, data):
        for attribute in ('road', 'city', 'county', 'contry', 'postcode'):
            try:
                value = data[attribute]
            except KeyError:
                value = None
            setattr(self, attribute, value)

class GeoResults(object):
    """Container for list of L{cloudmade.geocoging.GeoResult} objects

    @ivar found: Number of total results founded, can be more than len(results)
    @type found: C{int}
    @ivar results: List of founded L{cloudmade.geocoging.GeoResult} objects  
    @type found: C{list}
    @ivar bounds: Bounds of result set
    @type bounds: L{cloudmade.geometry.BBox}
    
    """   
    def __init__(self, data):
        self.found = int(data.get("found", 0))
        self.results = map(GeoResult, data.get("features", []))
        if "bounds" in data:
            self.bounds = geometry.BBox.from_coordinates(data.get("bounds"))
        else:
            self.bounds = None
        

class GeoResult(object):
    """Parsed result of geocoding request

    @ivar id: Id of the object
    @type id: C{int}
    @ivar geometry: Geometry of the object
    @ivar centroid: Centroid of the object
    @ivar bounds: Bounds of object's geometry
    @type bounds: L{cloudmade.geometry.BBox}
    @ivar properties: Properties of the object
    @ivar location: Location of the object
    @type location: L{cloudmade.geocoding.Location}
    
    """

    def __init__(self, data):
        self.id = data.get("id")
        self.geometry = geometry.parse_geometry_data(data.get("geometry"))
        self.centroid = geometry.parse_geometry_data(data.get("centroid"))
        self.bounds = geometry.BBox.from_coordinates(data.get("bounds"))
        self.properties = data.get("properties")
        if 'location' in data:
            self.location = Location(data.get("location"))
        else:
            self.location = None


def find(query, results=10, skip=0, bbox=None, bbox_only=True,
         return_geometry=True, connection=None, apikey=None, **kwargs):
    """Find object of given type which is closest to given point

    @note: If connection is not specified, apikey and optional keyword
    arguments will be used for creating Connection object

    @param query: Query by which objects should be searched.
    @type query: C{str}
    @param results: How many results should be returned.
    @type results: C{int}
    @param skip: Number of results to skip from beginning.
    @type skip: C{int}
    @param bbox: Bounding box in which objects should be searched.
    @type bbox: L{cloudmade.geometry.BBox}
    @param bbox_only: If set to False, results will be searched in the
    whole world if there are no results for a given bbox.
    @type bbox_only: C{bool}
    @param return_geometry: If specified, adds geometry in returned
    results. Defaults to True.
    @type return_geometry: C{bool}
    @param connection: Connection to CloudMade's services. Defaults to
    `None`.
    @type connection: L{cloudmade.connection.Connection}
    @param apikey: API key that should be used if `connection` argument
    is not specified. Default to `None`.
    @type apikey: C{str}
    @keyword host: Parameter passed to constructor of
    L{cloudmade.connection.Connection} object.
    @type host: C{str}
    @keyword port: Parameter passed to constructor of
    L{cloudmade.connection.Connection} object.
    @type port: C{str}
    @return: Found L{cloudmade.geocoging.GeoResults} object.
    @rtype: C{cloudmade.geocoging.GeoResults}
    
    """
    if connection is None:
        connection = Connection(**kwargs)
    geocodingobj = Geocoding(connection)
    return geocodingobj.find(query, results, skip, bbox, bbox_only, return_geometry)

def find_closest(object_type, point,
                 return_geometry=True, connection=None, apikey=None, **kwargs):
    """Find object of given type which is closest to given point

    @note: For a list of available object types, see:
    http://www.cloudmade.com/developers/docs/geocoding-http-api/object_types

    @note: If connection is not specified, apikey and optional keyword
    arguments will be used for creating Connection object

    @param object_type: Type of object, that should be searched.
    @type object_type: C{str}
    @param point: Closes object to this point will be searched.
    @type point: L{cloudmade.geometry.Point}
    @param return_geometry: If specified, adds geometry in returned
    results. Defaults to True.
    @type return_geometry: C{bool}
    @param connection: Connection to CloudMade's services. Defaults to
    `None`.
    @type connection: L{cloudmade.connection.Connection}
    @param apikey: API key that should be used if `connection` argument
    is not specified. Default to `None`.
    @type apikey: C{str}
    @keyword host: Parameter passed to constructor of
    L{cloudmade.connection.Connection} object.
    @type host: C{str}
    @keyword port: Parameter passed to constructor of
    L{cloudmade.connection.Connection} object.
    @type port: C{str}
    @return: Object that was found.
    @rtype: L{cloudmade.geocoging.GeoResult}
    @raise cloudmade.exception.ObjectNotFound: Raised when no object could
    be found in radius of 50 km from point.
    
    """
    if connection is None:
        connection = Connection(apikey, **kwargs)
    geocodingobj = Geocoding(connection)
    return geocodingobj.find_closest(object_type, point, return_geometry)
