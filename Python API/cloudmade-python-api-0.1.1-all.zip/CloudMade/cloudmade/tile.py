#!/usr/bin/env python
"""
 Copyright 2009 CloudMade.

 Licensed under the GNU Lesser General Public License, Version 3.0;
 You may not use this file except in compliance with the License.
 You may obtain a copy of the License at

      http://www.gnu.org/licenses/lgpl-3.0.txt

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
"""

"""Collection of CloudMade's tile APIs"""

import math

from connection import Connection

class Tile(object):
    """Class that is responsible for tile services of Cloudmade

    @ivar sub_domain: Subdomain of CloudMade's tile service
    @type sub_domain: C{str}
    @ivar connection: Connection object to be used by CloudMade's
    tile service
    @type connection: L{cloudmade.connection.Connection}
    @ivar tile_size: Length of requested tiles' sides
    @type tile_size: C{int}
    @ivar style_id: style id of the requested tile
    @type style_id: C{int}
    
    """

    def __init__(self, connection=None, tile_size=256, style_id=1):
        self.subdomain = "tile"
        self.connection = connection
        self.tile_size = tile_size        
        self.style_id = style_id
    
    def get(self, latitude, longitude, zoom):
        """Get tile with given latitude, longitude and zoom

        @param latitude: Latitude of requested tile
        @type latitude: C{float}
        @param longitude: Longitude of requested tile
        @type longitude: C{float}
        @param zoom: Zoom level, on which tile is being requested
        @type zoom: C{int}
        @return: Raw PNG data that was returned by request
        @rtype: C{str}
        
        """
        xtile, ytile = latlon2tilenums(latitude, longitude, zoom)
        pattern = "/%s/%s/%s/%s/%s.png"
        values = (self.style_id, self.tile_size, zoom, xtile, ytile)
        uri = pattern % values
        return self.connection.call_service(uri, subdomain=self.subdomain)


def latlon2tilenums(latitude, longitude, zoom):
    """Convert latitude, longitude pair to tile coordinates

    @param latitude: Latitude
    @type latitude: C{float}
    @param longitude: Longitude
    @type longitude: C{float}
    @param zoom: Zoom level
    @type zoom: C{int}
    @return: Tile coordinates
    @rtype: C{tuple}
    
    """
    factor = 2**(zoom - 1)
    latitude, longitude = map(math.radians, (latitude, longitude))
    xtile = 1 + longitude / math.pi
    ytile = 1 - math.log(math.tan(latitude) + (1 / math.cos(latitude))) \
            / math.pi
    return tuple(int(coord * factor) for coord in (xtile, ytile))
    

def tilenums2latlon(xtile, ytile, zoom):
    """Convert tile coordinates pair to latitude, longitude

    @param xtile: X coordinate of the tile
    @type xtile: C{int}
    @param ytile: Y coordinate of the tile
    @type ytile: C{int}
    @param zoom: Zoom level
    @type zoom: C{int}
    @return: Latitude, longitude pair
    @rtype: C{tuple}
    
    """
    factor = 2.0 ** zoom
    lon = (xtile * 360 / factor) - 180.0
    lat = math.atan(math.sinh(math.pi * (1 - 2 * ytile / factor)))
    return math.degrees(lat), lon


def get_tile(latitude, longitude, zoom,
             style_id=1, size=256, connection=None, apikey=None, **kwargs):
    """
    A wrapper for getting tiles.

    This is a thin wrapper aroung tile.Tile's get() method. If you don't
    want to pass connection object, you can specify
    connection.Connection arguments after all other arguments. For
    example:
    >>> get_tile(12, 345, 17, 2, apikey='123456678ABCDEFGH', secret_key=None,
    ... host='cloudmade.com', port='80')
    
    @param latitude: latitude of requested tile
    @type latitude: float
    @param longitude: longitude of requested tile
    @type longitude: float
    @param zoom: zoom level, on which tile is being requested
    @type zoom: C{int}
    @param style_id: style id of the requested tile
    @type style_id: C{int}
    @param size: Length of requested tiles' sides
    @type size: C{int}
    @param connection: connection object, to be used for getting tile.
    @type connection: L{cloudmade.connection.Connection}
    @param apikey: API key that should be used if `connection` argument
    is not specified.
    @type apikey: C{str}
    @keyword host: Parameter passed to constructor of
    L{cloudmade.connection.Connection} object.
    @type host: C{str}
    @keyword port: Parameter passed to constructor of
    L{cloudmade.connection.Connection} object.
    @type port: C{str}
    @return: Raw PNG data that was returned by request
    @rtype: C{str}
    
    """
    if connection is None:
        connection = Connection(apikey, **kwargs)
    tileobj = Tile(connection, size, style_id)
    return tileobj.get(latitude, longitude, zoom)

if __name__ == '__main__':
    pass
