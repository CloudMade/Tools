"""
 Copyright 2009 CloudMade.

 Licensed under the GNU Lesser General Public License, Version 3.0;
 You may not use this file except in compliance with the License.
 You may obtain a copy of the License at

      http://www.gnu.org/licenses/lgpl-3.0.txt

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
"""
import httplib

from exception import APIKeyMissingError, HTTPError

class Connection(object):   
    """Connection to CloudMade's services

    API Client object is initialized by user credentials
    (apikey/private key) as well as target (i.e. cloudmade)
    host, port, etc.

    @ivar apikey: API key used for connection
    @type apikey: C{str}
    @ivar host: Host of CloudMade's services
    @type host: C{str}
    @ivar port: HTTP port to be used for connection
    @type port: C{int}
    
    """
    
    def __init__(self, apikey, host="cloudmade.com", port=80):        
        if not apikey:
            raise APIKeyMissingError("API key is not specified")
        self.apikey = apikey
        self.host = host
        self.port = port
    
    def call_service(self, uri, subdomain=None):
        """Call CloudMade's service and return raw data

        @param uri: Tail part of full-blown request URL. For example:
        '/api/action/thingy?get=True'
        @type uri: C{str}
        @param subdomain: Subdomain, from which request should be
        processed
        @type subdomain: C{str}
        @return: Response of the service to the request
        @rtype: C{str}
        @raise cloudmade.exception.HTTPError: Raised when HTTP
        connection returns code other than 200
        
        """
        domain = self.host
        if subdomain:
            domain = '.'.join([subdomain, self.host])
        conn = httplib.HTTPConnection(domain, self.port)
        uri = ''.join(('/', self.apikey, uri))
        try:
            conn.request("GET", uri)
            response = conn.getresponse()
            if response.status != 200:
                raise HTTPError("Couldn't read data. HTTP status: %d, %s" % 
                                (response.status, response.reason))
            return response.read()
        finally:
            conn.close()

def get_connection(apikey=None, host='cloudmade.com', port=80):
    """Connection object factory

    @note: This function doesn't really do nothing useful right now and
    is subject to change. It will be expanded to a more functional
    version later.

    @param apikey: API key used for connection
    @type apikey: C{str}
    @param host: Host of CloudMade's services
    @type host: C{str}
    @param port: HTTP port to be used for connection
    @type port: C{int}
    @return: Constructed connection object
    @rtype: L{cloudmade.connection.Connection}

    """
    #TODO: add loading parameters from config
    conn = Connection(apikey, host, port)
    return conn
