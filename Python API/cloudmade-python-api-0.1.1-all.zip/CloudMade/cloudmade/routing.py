#!/usr/bin/env python

"""
 Copyright 2009 CloudMade.

 Licensed under the GNU Lesser General Public License, Version 3.0;
 You may not use this file except in compliance with the License.
 You may obtain a copy of the License at

      http://www.gnu.org/licenses/lgpl-3.0.txt

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
"""

"""CloudMade's routing API"""

import geometry
import simplejson
import urllib

from connection import Connection
from exception import RouteNotFound

ROUTE_TYPES = ('car', 'foot', 'bicycle')
OUTPUT_FORMATS = ('js', 'gpx')
STATUS_OK = 0
STATUS_ERROR = 1
EARTHS_DIRECTIONS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
TURN_TYPE = ["C", "TL", "TSLL", "TSHL", "TR", "TSLR", "TSHR", "U"]

class Routing(object):
    """Class corresponding for CloudMade's routing service

    @ivar sub_domain: Subdomain of CloudMade's routing service
    @type sub_domain: C{str}
    @ivar connection: Connection object to be used by CloudMade's
    routing service
    @type connection: L{cloudmade.connection.Connection}

    """
    
    def __init__(self, connection):
        self.sub_domain = "routes"
        self.connection = connection

    def route(self, start, end, type_,
              transit_points='', type_modifier='', lang="en", units="km"):
        """Build route

        @param start: Starting point
        @type start: L{cloudmade.geometry.Point}
        @param end: Ending point
        @type end: L{cloudmade.geometry.Point}
        @param type_: Type of route, e.g. 'car', 'foot', etc.
        @type type_: C{str}
        @param transit_points: List of points route must visit before
        reaching end. Points are visited in the same order they are
        specified in the sequence.
        @type transit_points: Any iterable object
        @param type_modifier: Modifier of the route type
        @type type_modifier: C{str}
        @param lang: Language code in conformance to `ISO 3166-1 alpha-2`
        standard
        @type lang: C{str}
        @param units: Measure units for distance calculation
        @type units: C{str}
        @return: Route that was found
        @rtype: L{cloudmade.routing.Route}

        """
        #TODO: add support for different output formats
        if type_ not in ROUTE_TYPES:
            raise ValueError("Routing type should one of the following: %s"
                             % ROUTE_TYPES)
        if transit_points:
            transit_points = ",[%s]" % ",".join([point.to_string() for point in transit_points])
        if type_modifier:
            type_modifier = "/%s" % urllib.quote(type_modifier)
        pattern = "/api/0.3/%s%s,%s/%s%s.js?lang=%s&units=%s"
        values = (start, transit_points, end, type_, type_modifier, lang, units)
        uri = pattern % values
        return self._call_service(uri)

    def _call_service(self, uri):
        """Make the call to CloudMade's service using underlying connection

        @note: This is an internal method and shouldn't be used directly

        @param uri: Request string
        @type uri: C{str}
        @return: Requested route
        @rtype: L{cloudmade.routing.Route}
        
        """
        raw = self.connection.call_service(uri, self.sub_domain)
        return Route(simplejson.loads(raw))

class Route(object):
    """Wrapper around raw data being returned by routing service

    @ivar instructions: List of instructions
    @type instructions: C{list}
    @ivar summary: Statistical info about the route
    @type summary: L{cloudmade.routing.RouteSummary}
    @ivar geometry: Geometry of route
    @type geometry: L{cloudmade.geometry.Line}
    @ivar version: Version of routing HTTP API
    @type version: C{str}
    
    """
      
    def __init__(self, response):
        """Custom initializer

        @param response: Decoded JSON response from the server
        @type response: C{Mapping}
        
        """
        try:
            self.instructions = map(RouteInstruction,
                                    response['route_instructions'])
            self.summary = RouteSummary(response['route_summary'])
            self.geometry = geometry.Line(response["route_geometry"])
            self.version = response['version']
        except KeyError:
            raise RouteNotFound(response.get('status_message', ''))
    

class RouteInstruction(object):
    """Instructions on route passing

    @ivar instruction: Text instruction
    @type instruction: C{str}
    @ivar length: Length of the segment in meters
    @type length: C{float}
    @ivar position: Index of the first point of the segment in route geometry
    @type position: C{int}
    @ivar time: Estimated time required to travel the segment in seconds
    @type time: C{int}
    @ivar length_caption: Length of the segments in specified units
    @type length_caption: C{str}
    @ivar earth_direction: Earth direction
    @type earth_direction: C{str}
    @ivar azimuth: North-based azimuth
    @type azimuth: C{float}
    @ivar turn_type: Code of the turn type
    @type turn_type: C{str}
    @ivar turn_angle: Angle in degress of the turn between two segments
    @type turn_angle: C{float}
    
    """
    
    def __init__(self, data):
        print data
        dispatch = (('instruction', None), ('length', float),
                    ('position', int), ('time', int), ('length_caption', None),
                    ('earth_direction', None), ('azimuth', float),
                    ('turn_type', None), ('turn_angle', float))
        for index, pair in zip(xrange(9), dispatch):
            attribute, func = pair
            try:
                value = data[index] 
                if func:
                    value = func(value)
            except IndexError:
                value = None
            setattr(self, attribute, value)

class RouteSummary(object):
    """Statistics of the route

    @todo: write docstring
    
    """
    
    def __init__(self, summary):
        self.total_distance = float(summary.get("total_distance"))
        self.total_time = float(summary.get("total_time"))
        self.start_point = summary.get("start_point")
        self.end_point = summary.get("end_point")
        self.transit_points = summary.get("transit_points")

def get_route(start, end, type_, transit_points='', type_modifier='',
              lang='en', units='km', connection=None, apikey=None, **kwargs):
    """Get route of given `type_` from `start` to `end`
    
    @param start: Starting point
    @type start: L{cloudmade.geometry.Point}
    @param end: Ending point
    @type end: L{cloudmade.geometry.Point}
    @param type_: Type of route, e.g. 'car', 'foot', etc.
    @type type_: C{str}
    @param transit_points: List of points route must visit before
    reaching end. Points are visited in the same order they are
    specified in the sequence.
    @type transit_points: C{Iterable}
    @param type_modifier: Modifier of the route type
    @type type_modifier: C{str}
    @param lang: Language code in conformance to `ISO 3166-1 alpha-2`
    standard
    @type lang: C{str}
    @param units: Measure units for distance calculation
    @type units: C{str}
    @param connection: Connection to CloudMade's services. Defaults to
    `None`.
    @type connection: L{cloudmade.connection.Connection}
    @param apikey: API key that should be used if `connection` argument
    is not specified. Default to `None`.
    @type apikey: C{str}
    @keyword host: Parameter passed to constructor of
    L{cloudmade.connection.Connection} object.
    @type host: C{str}
    @keyword port: Parameter passed to constructor of
    L{cloudmade.connection.Connection} object.
    @type port: C{str}
    @return: Route that was found
    @rtype: L{cloudmade.routing.Route}
    
    """
    if connection is None:
        connection = Connection(apikey, **kwargs)
    routingobj = Routing(connection)
    return routingobj.route(start, end, type_, transit_points, type_modifier,
                            lang, units)

