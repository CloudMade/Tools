#!/usr/bin/env python

"""
 Copyright 2009 CloudMade.

 Licensed under the GNU Lesser General Public License, Version 3.0;
 You may not use this file except in compliance with the License.
 You may obtain a copy of the License at

      http://www.gnu.org/licenses/lgpl-3.0.txt

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
"""

"""Different geometry objects
For use in CloudMade's API"""

from exception import GeometryParseError

class Geometry(object):
    """Base class for geometry objects"""
    pass

class Point(Geometry):
    """Simple container of latitude, longitude pair

    @ivar lat: Latitude
    @type lat: C{float}
    @ivar lon: Longitude
    @type lon: C{float}

    """
    
    def __init__(self, coordinates, lat_lon=True):
        if len(coordinates) == 1:
            coordinates = coordinates[0]
        if not lat_lon:
            coordinates = reversed(coordinates)
        self.lat, self.lon = map(float, coordinates)

    def to_string(self, lat_lon=True):
        """Text representation of point.

        @param lat_lon: Declare order: True - lat lon, False - lon lat 
        @type lat_lon: C{boolean}
        
        """
        if lat_lon:
            return "%s,%s" % (self.lat, self.lon)
        else:
            return "%s,%s" % (self.lon, self.lat)

    def __str__(self):
        return "%s,%s" % (self.lat, self.lon)

    def __repr__(self):
        return self.__str__()


class Line(Geometry):
    """Geometry object that consists of Point geometries

    @ivar points: List of points, that make up the line
    @type points: C{list}
    
    """
    
    def __init__(self, coordinates, lat_lon=True):
        self.points = [Point(coord, lat_lon) for coord in coordinates]


class MultiLine(Geometry):
    """Geometry object that consists of Line geometries

    @ivar lines: List of lines, that make up the multiline
    @type lines: C{list}
    
    """
    
    def __init__(self, coordinates, lat_lon=True):
        self.lines = [Line(coord, lat_lon) for coord in coordinates]


class Polygon(Geometry):
    """Geometry object that consists of Line geometries and has a closed form

    @ivar holes: List of lines that make up the holes in polygon
    @type holes: C{list}
    @ivar border_line: Border line of polygon
    @type border_line: L{cloudmade.geometry.Line}
    
    """

    def __init__(self, coordinates, lat_lon=True):
        self.border_line = Line(coordinates[0], lat_lon)
        self.holes = [Line(coord, lat_lon) for coord in coordinates[1:]]


class MultiPolygon(Geometry):
    """Geometry object that consists of Polygon geometries

    @ivar polygons: List of polygons, that make up the multipolygon
    @type polygons: C{list}

    """    

    def __init__(self, coordinates, lat_lon=True):
        self.polygons = [Polygon(coord, lat_lon) for coord in coordinates]


class BBox(object):
    """Bounding box object, which contains pair of points

    @ivar points: Pair of points, which correspond to low-left and
    upper-right coordinates respectively
    @type points: C{tuple}

    """
    
    def __init__(self, coordinates, lat_lon=True):
        self.points = tuple([Point(coord, lat_lon) for coord in coordinates])

    @classmethod
    def from_points(cls, point1, point2):
        """Alternative constructor for BBox

        Constructs object from two given points.

        @param point1: Low-left coordinate
        @type point1: L{cloudmade.geometry.Point}
        @param point2: Low-left coordinate
        @type point2: L{cloudmade.geometry.Point}
        @return: BBox instance
        @rtype: L{cloudmade.geometry.BBox}
        
        """
        obj = super(BBox, cls).__new__(cls, point1, point2)
        obj.points = point1, point2
        return obj

    @classmethod    
    def from_coordinates(cls, coordinates, lat_lon=True):
        """Copy of default constructor

        Constructs object from given sequence of points.
        
        @param coordinates: Pair of points, which correspond to low-left and
        upper-right coordinates respectively
        @type coordinates: C{Iterable}
        @return: BBox instance
        @rtype: L{cloudmade.geometry.BBox}
        
        """
        obj = super(BBox, cls).__new__(cls, coordinates)
        obj.__init__(coordinates, lat_lon)
        return obj

    def to_string(self, lat_lon=True):
        """Text representation of bbox.

        @param lat_lon: Declare order: True - lat lon, False - lon lat 
        @type lat_lon: C{boolean}
        
        """
        return "%s,%s" % tuple([point.to_string(lat_lon) for point in self.points])
    
    def __str__(self):
        return "%s, %s" % self.points

    def __repr__(self):
        return repr(self.points)
    

def parse_geometry_data(data, lat_lon=True):
    """Get geometry type of data and build corresponding object

    @param data: Geometry data to be parsed
    @type data: C{Mapping}
    @return: Corresponding geometry object
    @rtype: L{cloudmade.geometry.Geometry}
    
    """
    dispatch_type = {"point": Point,
                     "linestring": Line,
                     "multilinestring": MultiLine,
                     "polygon": Polygon,
                     "multipolygon": MultiPolygon}
    if data is None:
        return None
    type_ = data.get("type").lower()
    try:
        geometry_class = dispatch_type[type_]
        return geometry_class(data["coordinates"], lat_lon)
    except KeyError:
        raise GeometryParseError("Couldn't parse geometry data")
