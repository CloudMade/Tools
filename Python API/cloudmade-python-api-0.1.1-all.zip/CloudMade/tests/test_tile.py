"""
 Copyright 2009 CloudMade.

 Licensed under the GNU Lesser General Public License, Version 3.0;
 You may not use this file except in compliance with the License.
 You may obtain a copy of the License at

      http://www.gnu.org/licenses/lgpl-3.0.txt

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
"""
from cloudmade.tile import *
from cloudmade.connection import *
from test_connection import MockConnection

def test_latlon2tilenums():
    x, y = latlon2tilenums(11.1, 34.5, 15)
    assert x == 19524
    assert y == 15367
    
def test_tilenums2latlon():
    lat, lon = tilenums2latlon(19524, 15367, 15)
    assert round(lat, 1) == 11.1
    assert round(lon, 1) == 34.5    
    
def test_tile_get():
    conn = MockConnection(apikey="BC9A493B41014CAABB98F0471D759707", host="cloudmade.com", port=80)
    tile = Tile(connection=conn, tile_size=256, style_id=1)    
    conn.return_data = "PNG file content"
    png = tile.get(11.1, 34.5, 15)
    assert conn.uri == "/1/256/15/19524/15367.png"
    assert png == conn.return_data

def test_get_tile():
    conn = MockConnection(apikey="BC9A493B41014CAABB98F0471D759707", host="cloudmade.com", port=80)
    conn.return_data = "PNG file content"
    png = get_tile(11.1, 34.5, 15, tile_size=256, style_id=1, connection=conn)
    assert conn.uri == "/1/256/15/19524/15367.png"
    assert png == conn.return_data    
