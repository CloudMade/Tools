"""
 Copyright 2009 CloudMade.

 Licensed under the GNU Lesser General Public License, Version 3.0;
 You may not use this file except in compliance with the License.
 You may obtain a copy of the License at

      http://www.gnu.org/licenses/lgpl-3.0.txt

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
"""
from cloudmade.geometry import *

def test_point():
    coordinates = [0.2, 35.2]
    point = Point(coordinates)
    assert point.lat == 0.2
    assert point.lon == 35.2
    assert point.to_string() == "0.2,35.2"
    
    coordinates = [35.2, 0.2]    
    point = Point(coordinates, lat_lon=False)
    assert point.lat == 0.2
    assert point.lon == 35.2
    assert point.to_string() == "0.2,35.2"
    assert point.to_string(lat_lon=False) == "35.2,0.2"

def test_line():
    coordinates = [[0.2, 35.2], [4.3, 45.1], [5.7, 11.2]]
    line = Line(coordinates)
    assert len(line.points) == 3
    assert line.points[2].lat == 5.7
    assert line.points[2].lon == 11.2

def test_multi_line():
    coordinates = [[[0.2, 35.2], [4.3, 45.1], [5.7, 11.2]], [[1.1, 33.2], [5.3, 22.2]]]
    multi_line = MultiLine(coordinates)
    assert len(multi_line.lines) == 2
    assert len(multi_line.lines[1].points) == 2
    assert multi_line.lines[1].points[1].lon == 22.2

def test_polygon():
    coordinates = [[[0.2, 35.2], [4.3, 45.1], [5.7, 11.2]], [[1.1, 33.2], [5.3, 22.2]]]
    polygon = Polygon(coordinates)
    assert len(polygon.border_line.points) == 3
    assert len(polygon.holes) == 1
    assert polygon.holes[0].points[0].lat == 1.1

def test_multi_polygon():
    coordinates = [[[[0.2, 35.2], [4.3, 45.1]]], [[[1.1, 33.2], [5.3, 22.2]]]]
    multi_polygon = MultiPolygon(coordinates)
    assert len(multi_polygon.polygons) == 2
    assert len(multi_polygon.polygons[1].holes) == 0
    assert multi_polygon.polygons[0].border_line.points[0].lat == 0.2
    
def test_bbox():
    coordinates = [[0.2, 35.2], [4.3, 45.1]]
    point1 = Point(coordinates[0])
    point2 = Point(coordinates[1])
    bbox = BBox.from_points(point1, point2)
    assert bbox.to_string() == "0.2,35.2,4.3,45.1"
    bbox = BBox.from_coordinates(coordinates)
    assert bbox.to_string(lat_lon=False) == "35.2,0.2,45.1,4.3"
    
def test_parse_geometry_data():
    geom_data = {"type": "POINT", "coordinates": [51.5, -0.1]}
    geometry = parse_geometry_data(geom_data)
    assert isinstance(geometry, Point)
    geom_data = {"type": "MULTILINESTRING", "coordinates": [[[51.5, -0.1], [34.3, 1.1]]]}
    geometry = parse_geometry_data(geom_data)
    assert isinstance(geometry, MultiLine)
    try:
        geom_data = {"type": "POLY", "coordinates": [[51.5, -0.1], [34.3, 1.1]]}
        geometry = parse_geometry_data(geom_data)
        assert False
    except GeometryParseError:
        pass    
        
