CloudMade
++++++

CloudMade is a python API for CloudMade's online services: Geocoding, Routing and Tiles.

Full documentation is available online at http://cloudmade.com/developers/docs/

Install
=======

Using easy_install

	easy_install CloudMade

If you want to install from source you can run the following command:

    python setup.py install

Testing
=======

To test the source distribution you will need to install CloudMade and nose.


    easy_install nose

Once the required packages are installed you can run the tests with the 
following command in the root of the source tree:

    nosetests -v

Module Documentation
====================

To generate module documentation you will need to install epydoc the issue the following commands:

    easy_install epydoc

Then to build the documentation use this command:

    epydoc -v *.py

    
