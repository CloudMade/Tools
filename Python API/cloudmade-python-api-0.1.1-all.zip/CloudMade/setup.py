#!/usr/bin/env python

from setuptools import setup, find_packages

setup(
    name = "CloudMade",
    version = "0.1.1",
    description="CloudMade's online services client",
    long_description="""
CloudMade
======

The CloudMade is aimed at making access to CloudMade online services in Python easy.


Current Status
---------------

CloudMade 0.1.1 described on this page is stable.


Download and Installation
-------------------------

CloudMade can be installed with `Easy Install
<http://peak.telecommunity.com/DevCenter/EasyInstall>`_ by typing::

    > easy_install CloudMade

""",
    keywords='cloudmade geocoding routing tiles',
    license='LGPL',
    author='Taras Murashko, Andrii Mishovskyi',
    author_email='tmurashko@cogniance.com, amishkovskiy@cogniance.com',
    url='http://cloudmade.com/developers',
    packages=find_packages(exclude=['tests', 'tests.*']),
    zip_safe=False,
    include_package_data=True,
    test_suite='nose.collector',
    install_requires=[
        "simplejson>=2.0.6", "nose>=0.10.4",
    ],
    extras_require = {
        'doc': ['epydoc>=3.0']
        }
)
